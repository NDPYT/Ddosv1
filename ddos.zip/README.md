<h1 align="center">🚀 LoveTool V2 🚀</h1>
<em><h5 align="center">(Language: Python, Shell)</h5></em>
  
<p align="center">Vui lòng không tấn công các trang web liên quan tới chính phủ.</p>

<p align="center"><img src="https://i.imgur.com/ssXRy5P.jpeg" width="600" height="200" alt="Script"></p>
<p align="center"><img src="https://i.imgur.com/ZFPU2zj.png" width="800" height="500" alt="Demo DDoS"></p>

# Mothed

* Layer7 
* Layer4 ( Code Lỗi Nên Btri )

# Cách Vào Tool

* Vào CH Play Hoặc Appstore Tải Google Cloud Để Chạy Tool Nhé!

* ```git clone https://github.com/VH006/LoveToolV2```
* ```cd LoveToolV2```
* ```sh start.sh```
# Video Hướng Dẫn
* https://youtu.be/GVdXKgFA2gc
# Contact Me 
* Telegram: @hungtricker
* Zalo: 0359822840
* Facebook: @Users.ViDucHung.ProFile

# Donate 
* Momo: 0359822840 <br>
CTK: Vi Đức Hùng 
* Tsr: 0359822840 <br>
CTK: Vi Hùng
* SHB: 0000190506 <br>
CTK: VI DUC HUNG 

[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/VH006/LoveToolV2hit-counter&count_bg=%230BD4FF&title_bg=%23525050&icon=github.svg&icon_color=%23000000&title=Views&edge_flat=true)](https://hits.seeyoufarm.com)




